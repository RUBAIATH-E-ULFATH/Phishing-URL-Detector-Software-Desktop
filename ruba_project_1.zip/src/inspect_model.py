from src.build_dataset import *
from sklearn.externals import joblib
import pickle
import numpy as np

def main():
    url = "http://www.facebook.com/"

    X_test = feature_extract(url)
    print(X_test)
    X_test = (np.array(X_test)).reshape(1, -1)

    # Load the model from the file
    rf_from_joblib = joblib.load('/home/inan/PycharmProjects/Ruba Project Phising 1/notebook_files/model_rf_1.pkl')

    # Use the loaded model to make predictions
    # print(rf_from_joblib.predict(X_test)[0])

    if rf_from_joblib.predict(X_test)[0] == 1:
        print("This is a phising website")
    else:
        print("This is a genuine website")


if __name__ == "__main__":
    main()
